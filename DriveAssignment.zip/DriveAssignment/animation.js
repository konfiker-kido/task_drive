// Sample card data
const cardData = [
    { id: 1, name: 'Card 1', type: 'burner', owner_id: 'your', expiry: '2023-08-31' },
    { id: 2, name: 'Card 2', type: 'subscription', owner_id: 'all', limit: 100 },
    { id: 3, name: 'Card 3', type: 'burner', owner_id: 'blocked', expiry: '2023-07-15' },
    // ...more card data
  ];  
  
  // Display initial cards on page load
  window.onload = function() {
    displayCards('your');
  };
     
  // Filter and display cards based on tab and search input
  function filterCards(tab) {
    const searchInput = document.getElementById('searchInput').value.toLowerCase();
    const filteredCards = cardData.filter(card => {
      const matchesOwner = card.owner_id === tab;
      const matchesSearch = card.name.toLowerCase
      })
    }  

